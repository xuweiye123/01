const express=require('express');
const bodyParser=require('body-parser');
const mysql=require('mysql');
//创建web服务器
const app=express();
//设置端口
app.listen(8000);
//引入用户路由器
const proRouter=require('./router/pro.js');
//console.log(userRouter);
//托管静态资源到public目录
app.use( express.static('./public') );
app.use( bodyParser.urlencoded({
	extended: false
}) ); 
//挂载路由器（放最后）
app.use('/pro',proRouter);