#设置客户端连接服务器端编码
set names utf8;
#丢弃数据库如果存在
drop database if exists lvyou;
#创建数据库，设置存储的编码
create database lvyou charset=utf8;
#进入数据库
use lvyou;
create table lvyou_user (
  uid int(11)  primary key not null auto_increment,
  user_name varchar(32) default null,
  phone varchar(16) default null,
  email varchar(64) default null,
  date  date not null,
  place varchar(64) default null,
  man int(11) default null,
  content varchar(64) default null
)
insert into lvyou_user values (null, '丁丁', '13501234567',  'ding@qq.com', '2012-12-15', '湖北省随州市','2',null);
insert into lvyou_user values (null, '当当',  '13501234568', 'dang@qq.com', '2012-12-15', '湖北省随州市', '2',null);
insert into lvyou_user values (null, '兜兜', '13501234534', 'dou@qq.com', '2012-12-15', '湖北省随州市', '2',null);
insert into lvyou_user values (null, '丫丫',  '13501234560', 'ya@qq.com', '2012-12-15', '湖北省随州市', '2',null);
insert into lvyou_user values (null, '小新', '18888888888', 'admin@163.com', '2012-12-15', '湖北省随州市', '2',null);
insert into lvyou_user values (null, '所爱隔山海', '18888889999', 'cliu@163.com', '2012-12-15', '湖北省随州市','2',null);

